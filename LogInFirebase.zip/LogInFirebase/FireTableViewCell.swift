//
//  FireTableViewCell.swift
//  fireBase88
//
//  Created by islam magdy on 5/8/18.
//  Copyright © 2018 islam magdy. All rights reserved.
//

import UIKit
import SDWebImage
class FireTableViewCell: UITableViewCell {

    @IBOutlet weak var TheImage: UIImageView!
    @IBOutlet weak var Price: UILabel!
    @IBOutlet weak var Name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func Update(Product:ProductObject){
     
        Name.text = Product.Name
        Price.text = Product.Price
        guard let url = URL(string: Product.Images)else{
            return
        }
        TheImage.sd_setImage(with: url, completed: nil)
    }
    
    
    @IBOutlet weak var viewS: UIView!
        {didSet{
            viewS.layer.shadowColor = UIColor(red:0.69, green:0.75, blue:0.77, alpha:1.0).cgColor
            
            viewS.layer.shadowRadius = 4
            viewS.layer.shadowOpacity = 0.5
            viewS.layer.shadowOffset = CGSize(width: 0, height: 3)
        }}
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
