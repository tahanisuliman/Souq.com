//
//  ProductObject.swift
//  LogInFirebase
//
//  Created by Mohammed on 5/8/18.
//  Copyright © 2018 Tahani. All rights reserved.
//

import Foundation
import Firebase

class ProductObject{
    
    var ID : String
    var Name : String
    var Price : String
    var Images : String
    var Stamp : TimeInterval
    
    init(ID : String , Name : String , Price : String  , Images : String , Stamp : TimeInterval ) {
        
        self.ID = ID
        self.Name = Name
        self.Price = Price
        self.Images = Images
        self.Stamp = Stamp
        
    }
    
    init(Dictionary : [String : AnyObject]) {
        
        if let ID = Dictionary["ID"] as? String ,
            let Name = Dictionary["Name"] as? String ,
            let Price = Dictionary["Price"] as? String ,
            let Images = Dictionary["Images"] as? String ,
            let Stamp = Dictionary["Stamp"] as? TimeInterval
        {
            
            self.ID = ID
            self.Name = Name
            self.Price = Price
            self.Images = Images
            self.Stamp = Stamp
            
            return
        }
        self.ID = ""
        self.Name = ""
        self.Price = ""
        self.Images = ""
        self.Stamp = 0
        
    }
    
    var UserRecieved : (()->())?
    
    func GetDictionary()->[String : AnyObject] {
        var newDictionary : [String : AnyObject] = [:]
        newDictionary["ID"] = self.ID as AnyObject
        newDictionary["Name"] = self.Name as AnyObject
        newDictionary["Price"] = self.Price as AnyObject
        newDictionary["Images"] = self.Images as AnyObject
        newDictionary["Stamp"] = self.Stamp as AnyObject
        
        return newDictionary
    }
    
    func UploadInformations() {
        Database.database().reference().child("Products").child(self.ID).setValue(GetDictionary())

        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ProductsUpdated"), object: nil)
    }
    
    func RemoveFromDatabase() {
        Database.database().reference().child("Products").child(self.ID).removeValue()
        
        
        
        
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ProductRemoved"), object: nil)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ProductsUpdated"), object: nil)
    }

    
    
}


class ProductApi {
    
    //MARK: GETTING PRODUCTS
    
    // Accounts.count > 0 ? Accounts[Accounts.count - 1].Stamp : nil
    
    static func GetProducts(LastStamp : TimeInterval? , Completion : @escaping ([ProductObject]) -> ()) {
        var Ref : DatabaseQuery = Database.database().reference()
        if LastStamp == nil {
            Ref = Database.database().reference().child("Products").queryLimited(toLast: 20).queryOrdered(byChild: "Stamp")
        } else {
            Ref = Database.database().reference().child("Products").queryLimited(toLast: 20).queryOrdered(byChild: "Stamp").queryEnding(atValue: LastStamp! - 0.0000000000001)
        }
        Ref.removeAllObservers()
        Ref.observeSingleEvent(of: .value) { (Snapshot : DataSnapshot) in
            if !Snapshot.exists() { return }
            guard let Dictionary1 = Snapshot.value as? [String : AnyObject] else { return }
            var TProducts : [ProductObject] = []
            
            Dictionary1.values.forEach({
                guard let Dictionary2 = $0 as? [String : AnyObject] else { return }
                TProducts.append(ProductObject(Dictionary: Dictionary2))
            })
            Completion(TProducts)
        }
    }
    
    static func GetProductWith(ID : String ,completion : @escaping (_ Product : ProductObject)->()){
        Database.database().reference().child("Products").child(ID).observeSingleEvent(of: .value) { (Snapshot: DataSnapshot) in
            if Snapshot.exists() == false { return }
            guard let Dictionary = Snapshot.value as? [String : AnyObject] else { return }
            let newProduct = ProductObject(Dictionary: Dictionary)
            completion(newProduct)
        }
    }
    
    // hello world how are you man
    
    
}


