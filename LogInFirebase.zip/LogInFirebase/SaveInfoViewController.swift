//
//  SaveInfoViewController.swift
//  LogInFirebase
//
//  Created by Mohammed on 5/8/18.
//  Copyright © 2018 Tahani. All rights reserved.
//

import UIKit

class SaveInfoViewController: UIViewController ,UIImagePickerControllerDelegate , UINavigationControllerDelegate{

    @IBOutlet weak var TheImage: UIImageView!
    @IBOutlet weak var SaveOutlet: UIButton!
    @IBOutlet weak var Price: UITextField!
    @IBOutlet weak var Name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        let gesture = UITapGestureRecognizer(target: self, action: #selector(self.HandleImage))
        TheImage.addGestureRecognizer(gesture)
        TheImage.isUserInteractionEnabled = true
    }
    
    
    @objc func HandleImage(){
        let Picker = UIImagePickerController()
        Picker.allowsEditing = true
        Picker.delegate = self
        Picker.sourceType = .photoLibrary
        present(Picker, animated: true, completion: nil)
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let Image = info[UIImagePickerControllerEditedImage] as? UIImage
        TheImage.image = Image
        picker.dismiss(animated: true, completion: nil)
        
    }

    @IBAction func SaveAction(_ sender: Any) {
        guard let Name = Name.text , let Price = Price.text else {
            // error happened check all the informations and try again thanks
            let alertController = UIAlertController(title: "خطأ", message:  "الرجاء التحقق من جميع المعلومات قبل الارسال.", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "حسناً", style: .default, handler: nil)
            alertController.addAction(alertAction)
            present(alertController, animated: true, completion: nil)
            return
        }
        TheImage.image?.UploadInTwoSize(completion: {[weak self] (BigImageURL : String?, SmallImageURL : String?) in
            guard let BigImage = BigImageURL , let SmallImage = SmallImageURL else { return }

        let NewProduct = ProductObject(ID:  UUID().uuidString, Name: Name, Price: Price, Images: BigImage, Stamp: Date().timeIntervalSince1970)
         
            NewProduct.UploadInformations()
            self?.SaveOutlet.setTitle("تم الحفظ", for: .normal)
        })
        
    }
}
