//
//  TableViewController.swift
//  fireBase88
//
//  Created by islam magdy on 5/8/18.
//  Copyright © 2018 islam magdy. All rights reserved.
//

import UIKit

class TableViewController: UIViewController , UITableViewDelegate,UITableViewDataSource{
    
    var Array : [ProductObject] = [] {
        didSet { Array = Array.sorted(by: {$0.Stamp > $1.Stamp }) }
    }

    
    func GetData() {
        ProductApi.GetProducts(LastStamp: Array.count > 0 ? Array[Array.count - 1].Stamp : nil) {[weak self] (Products : [ProductObject]) in
            Products.forEach({self?.Array.append($0)})
            DispatchQueue.main.async {
                self?.TableFire.reloadData()
                self?.Loading.stopAnimating()
            }
        }
    }
    

    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(TableViewController.handleRefresh(_:)),for: UIControlEvents.valueChanged)
        refreshControl.tintColor = UIColor.red
        return refreshControl
    }()

    @objc func handleRefresh(_ refreshControl: UIRefreshControl) { TableViewController() ; refreshControl.endRefreshing() }
    
    func SetUpRefresher() { self.TableFire.addSubview(self.refreshControl) }
    
    @objc func RestartVC() { self.Loading.startAnimating() ; Array = [] ; TableFire.reloadData() ; GetData() }

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Array.count
    }
    
    
    //for change cell height
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {return 100.0
    }
    @IBOutlet weak var TableFire: UITableView!
    
    @IBOutlet weak var viewShadow: UIView!
    
    @IBOutlet weak var Loading: UIActivityIndicatorView!
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FireTableViewCell", for: indexPath) as!
        FireTableViewCell
        cell.Update(Product: Array[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        TableFire.register(UINib(nibName: "FireTableViewCell", bundle: nil),
                             forCellReuseIdentifier : "FireTableViewCell")
        GetData()
        SetUpRefresher()
        NotificationCenter.default.addObserver(self, selector: #selector(TableViewController.RestartVC), name: NSNotification.Name(rawValue: "ProductsUpdated"), object: nil)

        
        
        viewShadow.layer.shadowColor = UIColor(red:0.69, green:0.75, blue:0.77, alpha:1.0).cgColor
        
        viewShadow.layer.shadowRadius = 6
        viewShadow.layer.shadowOpacity = 0.5
        viewShadow.layer.shadowOffset = CGSize(width: 0, height: 5)
        
    }


}
