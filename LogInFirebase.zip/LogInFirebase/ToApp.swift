//
//  ToApp.swift
//  Design2
//
//  Created by Mohammed on 5/6/18.
//  Copyright © 2018 islam magdy. All rights reserved.
//

import UIKit
class ASCut {
    
    static func MKVC(SBN : String , VCN : String) -> UIViewController {
        let StoryBoard = UIStoryboard(name: SBN, bundle: nil)
        return StoryBoard.instantiateViewController(withIdentifier: VCN) as UIViewController
    }
    
}
