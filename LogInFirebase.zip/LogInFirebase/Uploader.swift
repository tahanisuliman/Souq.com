//
//  Uploader.swift
//  LogInFirebase
//
//  Created by Mohammed on 5/8/18.
//  Copyright © 2018 Tahani. All rights reserved.
//

import UIKit
import Firebase

class Uploader {
    
    static var shared = Uploader()
    
    var DidUploadOne : (() -> ())?
    var DidUploadAll : (()->())?
    var DidFailedUpload : (()->())?
    var UploadedImagesURLS : [String] = []
    
    func Upload(Images : [UIImage])  { UploadedImagesURLS = [] ; counter = 0 ;  self.Images = Images ; RecursivUploader() ; }
    private var Images : [UIImage] = []
    private var counter : Int = 0
    private func RecursivUploader() {
        if (Images.count > 0) == false { self.DidFailedUpload?() ; return }
        Images[counter].Upload {[weak self] (ImageURL : String?) in
            
            if self == nil { return }
            guard let url = ImageURL  else { self?.DidFailedUpload?() ; return }
            self?.UploadedImagesURLS.append(url)
            self?.DidUploadOne?()
            if self?.counter == self!.Images.count - 1 {
                self?.DidUploadAll?()
            } else {
                self?.RecursivUploader()
                self?.counter += 1
                
            }
            
        }
    }
    
    fileprivate func UploadInTwoSize(Image : UIImage , completion : @escaping (_ OriginalImage : String? , _ SmallImage : String? , _ ErrorMessage : String?) -> ()) {
        UploadImageToStorage(Image: Image) { (OriginalImageURL : String?) in
            guard let OriginalImage = OriginalImageURL else { completion(nil , nil , "Error") ; return }
            self.UploadImageToStorage(Image: Image.resize(size: 250)) { (SmallImageURL : String?) in
                guard let SmallImage = SmallImageURL else { completion(nil , nil , "Error") ; return }
                completion(OriginalImage, SmallImage, nil)
            }
        }
    }
    
    fileprivate func UploadImageToStorage(Image : UIImage , Completion : @escaping (_ ImageURL : String?)->()) {
        let metadata = StorageMetadata() ; metadata.contentType = "image/jpeg" ; let UID = UUID().uuidString
        guard let ImageData = UIImageJPEGRepresentation(Image, 0.8) else {
            print(">>> Error in Converting Image To Data <<<")
            Completion(nil)
            return
        }
        _ = Storage.storage().reference().child("StoredImages").child(UID).putData(ImageData, metadata: metadata) { (meta , error) in
            if error != nil {
                print(">>> Error in uploading image data to storage <<< " + (error?.localizedDescription)!)
                Completion(nil)
                return
            }
            Completion(meta?.downloadURL()?.absoluteString)
        }
    }
    
}

extension UIImage {
    
    func Upload(Completion : @escaping (_ ImageURL : String?)->()) {
        Uploader.shared.UploadImageToStorage(Image: self) { (ImageURL : String?) in
            Completion(ImageURL)
        }
    }
    
    func UploadInTwoSize(completion : @escaping (_ OriginalImage : String? , _ SmallImage : String?) -> ()) {
        Uploader.shared.UploadInTwoSize(Image: self) { (OriginalImageURL, SmallImageURL, ErrorMessage) in
            if ErrorMessage == nil {
                completion(OriginalImageURL, SmallImageURL)
            } else {
                completion(nil, nil)
            }
        }
    }
    
}
import CoreGraphics
extension UIImage {
    func resize(size: CGFloat) -> UIImage {
        if self.size.width < size || self.size.height < size {
            return self
        }
        let scale = size / self.size.width
        let newHeight = self.size.height * scale
        UIGraphicsBeginImageContext(CGSize(width: size, height: newHeight))
        self.draw(in: CGRect(x: 0, y: 0,width: size, height: newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
}
